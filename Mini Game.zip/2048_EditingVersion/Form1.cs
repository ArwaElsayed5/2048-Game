﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2048_EditingVersion
{
    public class CActor
    {
        public int X, Y, W, H, f;
        public string id;
    }
    public class CRec
    {
        public int X, Y, W, H;
    }
    public partial class Form1 : Form
    {
        Bitmap off;
        Random RR = new Random();
        Random rr = new Random();
        int nRows = 4, nCols = 4, Wd = 100, Ht = 100;
        int XB = 450, YB = 150, Flag=0;
        List<CRec> LRec = new List<CRec>();
        CActor[,] Squares;
        CActor[,] SquaresNew;
        public Form1()
        {
            this.WindowState = FormWindowState.Maximized;
            this.Paint += new PaintEventHandler(Form1_Paint);
            this.Load += new EventHandler(Form1_Load);
            this.MouseDown += new MouseEventHandler(Form1_MouseDown);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            off = new Bitmap(ClientSize.Width, ClientSize.Height);
            CreateRec();
            CreateSquares();
        }
        void Form1_Paint(object sender, PaintEventArgs e)
        {
            DrawDubb(e.Graphics);
        }
        void CreateRec()
        {
            int tx = 450;
            int ty = 150;
            CRec pnn = new CRec();
            pnn.X = 450;
            pnn.Y = 150;
            pnn.W = 400;
            pnn.H =400;
            LRec.Add(pnn);
        }
        void DrawDubb(Graphics g)
        {
            Graphics g2 = Graphics.FromImage(off);
            DrawScene(g2);
            g.DrawImage(off, 0, 0);
        }
        void CreateSquares()
        {
            int Sqx = XB;
            int Sqy = YB;
            Sqy = YB + 10;
            string[] RandNum = { "2", "4" };
            string[] RandNum2 = { "2", "4" };
            int mIndex = rr.Next(RandNum.Length);
            int mIndex2 = rr.Next(RandNum2.Length);
            SquaresNew = new CActor[nRows, nCols];
            int a = RR.Next(3);
            int b = RR.Next(3);
            int a2 = RR.Next(3);
            int b2= RR.Next(3);
            if(a==a2 && b==b2)
            {
                a2 = RR.Next(3);
                b2 = RR.Next(3);
            }
            for (int r = 0; r < nRows; r++)
            {
                Sqx = XB + 10;
                for (int c = 0; c < nCols; c++)
                {
                    CActor pnn = new CActor();
                    pnn.X = Sqx;
                    pnn.Y = Sqy;
                    pnn.W = 85;
                    pnn.H = 85;
                    SquaresNew[r, c] = pnn;
                    if (SquaresNew[r, c] == SquaresNew[a, b])
                    {
                        pnn.f = 1;
                        pnn.id = RandNum[mIndex];
                    }
                    if (SquaresNew[r, c] == SquaresNew[a2, b2])
                    {
                        pnn.f = 1;
                        pnn.id = RandNum2[mIndex2];
                    }

                    Sqx += 98;
                }
                Sqy += 98;
            }

        }
        void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                Flag = 1;
                for(int r=0;r<nRows; r++)
                {
                    for(int c=0;c<nCols;c++)
                    {

                    }
                }
            }
        }
        void DrawScene(Graphics g2)
        {
            SolidBrush brsh;
            brsh = new SolidBrush(Color.DimGray);
            g2.FillRectangle(brsh, LRec[0].X, LRec[0].Y,
                LRec[0].W, LRec[0].H);
            for (int r = 0; r < nRows; r++)
            {
                for (int c = 0; c < nCols; c++)
                {
                    brsh = new SolidBrush(Color.Gray);
                    g2.FillRectangle(brsh, SquaresNew[r, c].X, SquaresNew[r, c].Y,
                        SquaresNew[r, c].W, SquaresNew[r, c].H);

                }
            }
            Font Fnt = new Font("System", 50);
            for (int r = 0; r < nRows; r++)
            {
                for (int c = 0; c < nCols; c++)
                {
                    if(SquaresNew[r,c].f==1)
                    {
                        if (SquaresNew[r, c].id == "2")
                        {
                            brsh = new SolidBrush(Color.LightGray);
                            g2.FillRectangle(brsh, SquaresNew[r, c].X, SquaresNew[r, c].Y,
                            SquaresNew[r, c].W, SquaresNew[r, c].H);
                            g2.DrawString(SquaresNew[r, c].id + "", Fnt, Brushes.DarkSlateGray,
                            SquaresNew[r, c].X + 10, SquaresNew[r, c].Y + 5);
                        }
                        if (SquaresNew[r, c].id == "4")
                        {
                            brsh = new SolidBrush(Color.DarkGray);
                            g2.FillRectangle(brsh, SquaresNew[r, c].X, SquaresNew[r, c].Y,
                            SquaresNew[r, c].W, SquaresNew[r, c].H);
                            g2.DrawString(SquaresNew[r, c].id + "", Fnt, Brushes.DarkSlateGray,
                            SquaresNew[r, c].X + 10, SquaresNew[r, c].Y + 5);
                        }
                    }
                }
            }
            
        }
    }
}
